package pruebas;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

public class persistencia {
    public static List<String> rutasEncontradas = new ArrayList<>();
    
    public static void buscarArchivosPorNumeros(ArrayList<Integer> numeros, String carpeta) {
        
        File directorio = new File(carpeta);

        if (!directorio.exists() || !directorio.isDirectory()) {
            System.out.println("La carpeta especificada no existe o no es un directorio.");
        }

        File[] archivos = directorio.listFiles();
        if (archivos != null) {
            for (File archivo : archivos) {
                if (archivo.isFile()) {
                    String nombreArchivo = archivo.getName();
                    
                    for (int num : numeros) {
                        if (nombreArchivo.contains(String.valueOf(num))) {
                            rutasEncontradas.add(archivo.getAbsolutePath());
                            JOptionPane.showMessageDialog(null, "Encontrada carpeta " + archivo.getName());
                            break; // Evita agregar la misma ruta varias veces
                        }
                    }
                }
            }
        }  
    }
    public static void unirArchivos(String[] rutas, String archivoSalida) {
        try {
            List<String> pdfsConvertidos = new ArrayList<>();

            for (String ruta : rutas) {
                File archivo = new File(ruta);
                if (archivo.exists()) {
                    String extension = ruta.substring(ruta.lastIndexOf(".") + 1).toLowerCase();
                    String pdfTemporal = ruta.replace("." + extension, ".pdf");

                    switch (extension) {
                        case "docx":
                            convertirWordAPDF(ruta, pdfTemporal);
                            break;
                        case "jpg":
                        case "jpeg":
                            convertirImagenAPDF(ruta, pdfTemporal);
                            break;
                        case "pdf":
                            pdfTemporal = ruta; // Si ya es PDF, no hace conversión
                            break;
                        default:
                            System.out.println("Formato no soportado: " + ruta);
                            continue;
                    }
                    pdfsConvertidos.add(pdfTemporal);
                } else {
                    System.out.println("El archivo no existe: " + ruta);
                }
            }

            // Unir los PDFs generados
            if (!pdfsConvertidos.isEmpty()) {
                unirPDFs(pdfsConvertidos, archivoSalida);
                System.out.println("PDF final creado en: " + archivoSalida);
            } else {
                System.out.println("No se encontraron archivos para unir.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void convertirWordAPDF(String rutaWord, String rutaPDF) {
    try (FileInputStream fis = new FileInputStream(rutaWord);
         XWPFDocument document = new XWPFDocument(fis);
         PDDocument pdf = new PDDocument()) {

        PDPage page = new PDPage(PDRectangle.A4);
        pdf.addPage(page);
        PDPageContentStream contentStream = new PDPageContentStream(pdf, page);
        
        PDFont font = PDType1Font.HELVETICA;
        contentStream.setFont(font, 12);
        
        float y = 750; // Posición inicial
        contentStream.beginText();
        contentStream.newLineAtOffset(50, y);

        for (XWPFParagraph para : document.getParagraphs()) {
            contentStream.showText(para.getText());
            y -= 20; // Mueve hacia abajo
            contentStream.newLineAtOffset(0, -20);
        }

        contentStream.endText();
        contentStream.close();
        
        pdf.save(rutaPDF);
        pdf.close();

        System.out.println("✅ Word convertido a PDF: " + rutaPDF);
    } catch (Exception e) {
        System.out.println("❌ Error convirtiendo Word a PDF: " + e.getMessage());
    }
}

    public static void convertirImagenAPDF(String rutaImagen, String rutaPDF) {
        try {
            // Crear documento PDF
            PdfDocument pdfDoc = new PdfDocument(new PdfWriter(rutaPDF));
            Document document = new Document(pdfDoc);

            // Cargar la imagen
            ImageData imageData = ImageDataFactory.create(rutaImagen);
            Image img = new Image(imageData);

            // Ajustar tamaño al de la página
            pdfDoc.setDefaultPageSize(new PageSize(img.getImageWidth(), img.getImageHeight()));

            // Agregar la imagen al documento
            document.add(img);

            // Cerrar documentos
            document.close();
            pdfDoc.close();

            System.out.println("Imagen convertida a PDF: " + rutaPDF);
        } catch (Exception e) {
            System.out.println("Error convirtiendo Imagen a PDF: " + e.getMessage());
        }
    }

    public static void unirPDFs(List<String> archivosPDF, String salida) {
        try {
            PDFMergerUtility merger = new PDFMergerUtility();
            merger.setDestinationFileName(salida);

            for (String pdf : archivosPDF) {
                merger.addSource(pdf);
            }

            merger.mergeDocuments(null);
            System.out.println("PDFs combinados en: " + salida);
        } catch (Exception e) {
            System.out.println("Error al unir PDFs: " + e.getMessage());
        }
    }
}
