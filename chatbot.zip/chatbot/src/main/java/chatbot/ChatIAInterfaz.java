
package chatbot;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChatIAInterfaz extends JFrame {
    private JTextArea areaChat;
    private JTextField campoMensaje;
    private JButton botonEnviar;
    private ChatIAClient clienteIA;

    public ChatIAInterfaz() {
        setTitle("Chat con IA - Hugging Face");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        areaChat = new JTextArea();
        areaChat.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaChat);
        add(scroll, BorderLayout.CENTER);

        JPanel panelInferior = new JPanel(new BorderLayout());
        campoMensaje = new JTextField();
        botonEnviar = new JButton("Enviar");

        panelInferior.add(campoMensaje, BorderLayout.CENTER);
        panelInferior.add(botonEnviar, BorderLayout.EAST);
        add(panelInferior, BorderLayout.SOUTH);

        clienteIA = new ChatIAClient();

        botonEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enviarMensaje();
            }
        });

        campoMensaje.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enviarMensaje();
            }
        });
    }

    private void enviarMensaje() {
        String mensaje = campoMensaje.getText().trim();
        if (!mensaje.isEmpty()) {
            areaChat.append("Tú: " + mensaje + "\n");
            campoMensaje.setText("");

            new Thread(() -> {
                String respuestaIA = clienteIA.enviarMensaje(mensaje);
                SwingUtilities.invokeLater(() -> areaChat.append("IA: " + respuestaIA + "\n"));
            }).start();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ChatIAInterfaz ventana = new ChatIAInterfaz();
            ventana.setVisible(true);
        });
    }
}
