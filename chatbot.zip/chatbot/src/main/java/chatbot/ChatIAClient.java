
package chatbot;


import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.json.JSONArray;
import org.json.JSONObject;

public class ChatIAClient {
    public String enviarMensaje(String mensaje) {
        try {
            HttpClient clienteHttp = HttpClient.newHttpClient();
            JSONObject cuerpo = new JSONObject();
            cuerpo.put("inputs", mensaje);

            HttpRequest solicitud = HttpRequest.newBuilder()
                .uri(URI.create("https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.1"))
                .header("Content-Type", "application/json")
                .header("User-Agent", "Java-HttpClient")
                .POST(HttpRequest.BodyPublishers.ofString(cuerpo.toString()))
                .build();

            HttpResponse<String> respuesta = clienteHttp.send(solicitud, HttpResponse.BodyHandlers.ofString());

            if (respuesta.statusCode() != 200) {
                return "Error: La API devolvió el código " + respuesta.statusCode();
            }

            JSONArray jsonRespuesta = new JSONArray(respuesta.body());
            return jsonRespuesta.getJSONObject(0).getString("generated_text");

        } catch (Exception e) {
            return "Error al conectar con la IA: " + e.getMessage();
        }
    }
}
